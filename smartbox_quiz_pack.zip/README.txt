SMARTBOX MINI-JUEGO (WEB ESTÁTICA)
=================================

Qué incluye:
- index.html (página principal)
- style.css (estilos)
- script.js (preguntas + lógica de decisiones)

Cómo usarlo (rápido):
1) Abre index.html (funciona sin internet si lo abres como archivo).
2) Si quieres un LINK: súbelo a una web estática (recomendado: GitHub Pages).

Publicarlo en GitHub Pages (5 minutos):
1) Crea un repositorio nuevo en GitHub, por ejemplo: smartbox-quiz
2) Sube estos 3 archivos: index.html, style.css, script.js
3) En GitHub: Settings → Pages → 'Deploy from a branch'
   Branch: main / root
4) GitHub te dará una URL tipo:
   https://TUUSUARIO.github.io/smartbox-quiz/

Generar el QR:
- Cuando tengas la URL final, genera un QR con cualquier generador online
  o con un script (si quieres te lo preparo ya con tu URL final).
